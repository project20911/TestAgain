var host = "https://mazii.net";
var isShowDrawingKaji = false;

(function (i, s, o, g, r, a, m) {
    i['GoogleAnalyticsObject'] = r;
    i[r] = i[r] || function () {
        (i[r].q = i[r].q || []).push(arguments)
    }, i[r].l = 1 * new Date();
    a = s.createElement(o),
    m = s.getElementsByTagName(o)[0];
    a.async = 1;
    a.src = g;
    m.parentNode.insertBefore(a, m)
})(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');

$(document).ready(function(){

    ga('create', 'UA-47792030-2', 'mazii-chrome');
    ga('send', 'popup');
    
    $(".product-name-link").click(function() {
        openNewTab(host);
    });
    
    
    searchTextbox = $('#dict-search');

    
    var key = JSON.parse(localStorage.getItem('key'));
    if(key == null || key == undefined){
        key = [];
    }
    searchTextbox.keypress(function(event){
        $(".history").hide();
        // catch ENTER key
        if (event.keyCode == 13){
            var keyword = $(this).val();
            keyword = keyword.trim();
            if (keyword != ''){   
                searchTextbox.blur(); // lam mo
                search(keyword);
                key.splice(0,0,keyword);
                localStorage.setItem('key',JSON.stringify(key));
            }
        }
    });
    
    
    $("#search-button").click(function(e) {
        var keyword = searchTextbox.val();
        keyword = keyword.trim();
        if (keyword != ''){
            search(keyword);

           
        }
    } );

    
    // get options
    getOptions(function(data) {
        options = data;
    
        if (langPack == null) {
            getLanguagePack(options.lang, function() {
                initLanguage();
            });
        } else {
            initLanguage();
        }
        
    });

    var kanjiWriter = null;
    $("#show-draw-kanji").click(function() {
        if (isShowDrawingKaji == false) {
            $(".drawkanji-table").removeClass("mazii_hide");
            isShowDrawingKaji = true;
            if (kanjiWriter == null)
            kanjiWriter = new KanjiWriter({
                canvasId: "draw-canvas",
                colorDraw: "black",
                lineWidthDraw: 4,
                resultId: "#found_kanji",
                clearButtonId: "#drawkanji-clear-button",
                backButtonId: "#drawkanji-back-line-button",
                classResult: "draw-kanji-suggest",
                resultClickCallback: function() {
                    var k = $(this).text();
                    if (k != null &&
                       k != "") {
                        //$(selector).trigger(event,eventObj,param1,param2,...)
                        //trigger():kich hoat su kien da chi dinh
                        $("#drawkanji-clear-button").trigger("click");
                        var currentText = searchTextbox.val();
                        currentText += k;
                        searchTextbox.val(currentText);
                    }
                }
            });
            
        } else {
            $(".drawkanji-table").addClass("mazii_hide");
            isShowDrawingKaji = false;
        }
        
    });
    
    $("#close_draw").click(function(){
        if (isShowDrawingKaji == true) {
            $(".drawkanji-table").addClass("mazii_hide");
            isShowDrawingKaji = false;
        }
    });
    
    $(".option-link").click(function(){
        openNewTab(chrome.extension.getURL('option.html'));
    });
    
});

function openNewTab(url) {
    chrome.tabs.create({
        url: url
    })
}


function registerEventClickResult() {
    $("#found_kanji a").click(function() {
        var k = $(this).text();
        if (k != null &&
           k != "") {

            // append to search box
            var currentText = searchTextbox.val();
            currentText += k;
            searchTextbox.val(currentText);
            
            drawkanji.clearAll();
        }
    });
}
function printHTML(query, data, gg) {
    
    var hanViet = "";
    if (maziiDict != null && options.lang == "vi") {
        hanViet = getHVOfKey(query);
    }

    var markup = '';
    if (gg == null) {
        if (options.lang == "vi" && options.langFrom =="ja") {
            markup = printMaziiVi(getMatchResult(data, query), hanViet);
            linkmore = 'https://mazii.net/search?dict=javi&type=w&hl=vi-VN&query=' + query + '&utm_source=mazii_chrome';
        } else if ((options.lang == "en" || options.lang == 'en_US') && options.langFrom =="ja") {
            markup = printMaziiVi(getMatchResult(data, query), "");
            linkmore = 'https://mazii.net/search?dict=jaen&type=w&hl=en-US&query=' + query + '&utm_source=mazii_chrome';

        } else {
            markup = printGT(data, hanViet);
        }
    } else {
        markup = printGT(data, hanViet);

    }




    $("#result-search").html(markup);
    
    var soundBtn = document.getElementById('pronoun-button');
    if (soundBtn == null)
        return;

    // cach phat am
    document.getElementById('pronoun-button').onclick = function() {
        var audioSource = document.getElementById('audio-source').getAttribute('src');
        chrome.extension.sendMessage({
            request: 'playPronoun',
            src: audioSource
        }, function(response) {
        });
    };
}

function search(query) {
    
    if (options.lang == "vi" && options.langFrom =="ja" && maziiDict == null) {
        getMaziiDict();
    }
    
    requestXHTML(getUrlQuery(query), function(data) {
        data = JSON.parse(data);
        if (options.lang == "vi" && options.langFrom =="ja" && (data.status == 302 || data.found == false)) {
            requestXHTML(getUrlQuery(query, true), function(data) {
                data = JSON.parse(data);
                printHTML(query, data, true);


            })    
        } else {
            printHTML(query, data);

        }

    });


}

function initLanguage() {
    
    $('#dict-search').attr('placeholder', getTextOf('search_box_suggest'));
    $('#show-draw-kanji').attr('title', getTextOf('pen_draw_tooltip'));
    $('#search-button').html(getTextOf('translate_button'));
    $('.m-tip').html(getTextOf('tip'));
    $('#close_draw').attr('alt', getTextOf('close_kanji_board'));
    $('#drawkanji-clear-button').attr('value', getTextOf('draw_kanji_erase_all'));
    $('#drawkanji-back-line-button').attr('value', getTextOf('draw_kanji_erase_last_stroke'));
    $('.option-link').html(getTextOf('option'));
    $('.click-rate').html(getTextOf('rate'));
    $('.click-share').html(getTextOf('share'));
    $('.text-empty').html(getTextOf('textEmpty'));
    $('.link-more').html(getTextOf('textDetail'));
    $('.click-Delete').html(getTextOf('deleteText'));
    $('#click-guide').html(getTextOf('guideText'));

}