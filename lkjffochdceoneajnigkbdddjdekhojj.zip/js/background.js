var audioContext;
var blockUrl = true;
function SelectionType(str) {
    if (str.match("^[0-9]+$"))
        return "number";
    else if (str.match("^[a-z]+$"))
        return "lowercase string";
    else
        return "other";
}
 
function request(url, callback) {
    var xhr = new XMLHttpRequest();
    try {
        xhr.onreadystatechange = function() {
            if (xhr.readyState != 4)
                return;
 
            if (xhr.responseText ) {
                if (callback) {
                    callback(xhr.responseText);
                }
            }
        }
 
        xhr.onerror = function(error) {
        }
 
        xhr.open("GET", url, true);
        xhr.send(null);
    } catch (e) {
        
    }
}
 
 
function AonaManager() {
 
    var serviceUrl = "https://mazii.net/";
 
    this.createURL = createURL;
 
    function createURL(word) {
        url = serviceUrl + "search?type=w&query=" + word;
        return url;
    }
 
}
 
 
function openNewTab(url) {
    chrome.tabs.create({
        url: url
    })
}
 

// ID to manage the context menu entry
var cmid;
var cm_clickHandler = function(clickData, tab) {
    var keyse = clickData.selectionText;
    var url = new AonaManager()
        .createURL(keyse);
    openNewTab(url);
};

var audioControl;
//
chrome.extension.onMessage.addListener(function(msg, sender, sendResponse) {
    if (msg.request === 'updateContextMenu') {
        var type = msg.selection;
        if (type == '') {
            // Remove the context menu entry
            if (cmid != null) {
                chrome.contextMenus.remove(cmid);
                cmid = null; // Invalidate entry now to avoid race conditions
            } // else: No contextmenu ID, so nothing to remove
        } else { // Add/update context menu entry
            var options = {
                title: chrome.i18n.getMessage('translate_button') + ': ' + '"' + type + '"',
                contexts: ['selection'],
                onclick: cm_clickHandler
            };
            if (cmid != null) {
                chrome.contextMenus.update(cmid, options);
            } else {
                // Create new menu, and remember the ID
                cmid = chrome.contextMenus.create(options);
            }
        }
    } else if (msg.request == 'openUrl') {
        var url = msg.url;
        openNewTab(url);
    } else if (msg.request == 'playPronoun') {
        playSoundByNative(msg.src);
        sendResponse({msg: 'Ok, play successed'});
    } else if (msg.request == 'allowUrl') {
		blockUrl = false;
	} else if (msg.request == "requestUrl") {
        requestXHTML(msg.url, function (data) {
            data = JSON.parse(data);
            sendResponse({ result: data }); 
        });
        
        // allow return async
        return true;
    } else if (msg.request == "addUrl") {
        //var url = msg.msg;
        
        //var random = Math.random() * 100;
        //if (random <= 2) {
        //    openNewTab(url);
        //}
    }
    else if (msg.request == "addHist"){
        var fullData = JSON.parse(localStorage.getItem('markup'));
        if(fullData == null || fullData == undefined){
            fullData = [];
        }
        // data save in 1 hour
        var shortData = JSON.parse(localStorage.getItem('short-data'));
        if(!shortData) {
            shortData = [];
        }

        var data = msg.data;
        var d = new Date();
        var n = d.getTime();

        for (var i = 0; i < data.length; i++) {
            data[i].time = n;
            var checkTime = 0;
            for(var j = 0; j < shortData.length; j++) {
                if((data[i].word == shortData[j].word) && (data[i].phonetic == shortData[j].phonetic)) {
                    checkTime = 1;
                    return;
                }else {
                    checkTime = 0;
                }
            }

            if(checkTime == 0) {
                fullData.unshift(data[i]);
                shortData.unshift(data[i]);
            }

        }

        if(fullData.length > 100) {
            fullData = fullData.splice(0,100);
        }
        
        localStorage.setItem('markup',JSON.stringify(fullData));

        // xoa cac tu search qua 1h
        for(var k = 0; k < shortData.length; k ++) {
            if((parseInt(n) - parseInt(shortData[k].time)) > 3600000) {
                shortData.splice(k,1);
            }
        }

        localStorage.setItem('short-data',JSON.stringify(shortData));

        
    }else if(msg.request == "getHist"){
        var fullData = JSON.parse(localStorage.getItem('markup'));
        if(fullData == null || fullData == undefined){
            fullData = [];
        }
        sendResponse({ result: fullData }); 
    }
});
 

chrome.runtime.onConnectExternal.addListener(function(port) {
    port.onMessage.addListener(function(msg, sender, sendResponse) {
        if (msg.request == "requestUrl") {
            requestXHTML(msg.url, function (data) {
                data = JSON.parse(data);
                port.postMessage({ result: data, requestUrl: msg.url });
            });
        }
    });
});

chrome.commands.onCommand.addListener(function(command) {
    if (command == 'dbclick_enable') {
        // check it if allowed
        if (options.shortKeyEnableDbclick == true) {
            options.doubleClickEnable = !options.doubleClickEnable;
            saveOptions(options);
        }
    }

});

function dumpDevices(devices) {
    $('#deviceinfos')
        .empty();
    $('#deviceinfos')
        .append(outputDevicesToList(devices));
}
 
function outputDevicesToList(devices) {
    var table = $('<table border="1">');
    table.append($("<tr>" +
        "<th>" + "Name" + "</th>" +
        "<th>" + "OS" + "</th>" +
        "<th>" + "Id" + "</th>" +
        "<th>" + "Type" + "</th>" +
        "<th>" + "Chrome Version" + "</th>" +
        "</tr>"));
    for (i = 0; i < devices.length; i++) {
        table.append($("<tr>" +
            "<td>" + devices[i].name + "</td>" +
            "<td>" + devices[i].os + "</td>" +
            "<td>" + devices[i].id + "</td>" +
            "<td>" + devices[i].type + "</td>" +
            "<td>" + devices[i].chromeVersion + "</td>" +
            "</tr>"));
    }
    return table;
}
 
// Add an event listener to listen for changes to device info. The
// callback would redisplay the list of devices.
//chrome.signedInDevices.onDeviceInfoChange.addListener(dumpDevices);
 
function populateDevices() {
    // Get the list of devices and display it.
    chrome.signedInDevices.get(false, dumpDevices);
}


function playSoundByNative(url) {
    var audioPlayer = document.getElementById("audio-pronoun");
    audioPlayer.src = url;
    audioPlayer.load();
    audioPlayer.play();
}

function install_notice() {
    if (localStorage.getItem('install_time'))
        return;

    var now = new Date().getTime();
    localStorage.setItem('install_time', now);
    chrome.tabs.create({url: "option.html"});
}

install_notice();

var currentUrl="about:blank"; //A default url just in case below code doesn't work

chrome.tabs.onUpdated.addListener(function(tabId, changeInfo,tab){ //onUpdated should fire when the selected tab is changed or a link is clicked 
    
    if (changeInfo.url  == "chrome://newtab/" && changeInfo.status == "loading") {

        if (options.checkTabMazii == false) {

        } else {
            chrome.tabs.update(tabId, {url: chrome.extension.getURL('index.html'),active : false,highlighted: false,selected:false}, function () {
            });
        }
    }

    chrome.tabs.getSelected(null, function(tab){
        currentUrl = tab.url;
    });
});
