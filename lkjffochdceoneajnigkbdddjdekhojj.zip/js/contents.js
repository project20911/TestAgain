document.addEventListener('selectionchange', function() {
    var selection = window.getSelection()
        .toString()
        .trim();
    if (chrome && chrome.extension) {
        chrome.extension.sendMessage({
            request: 'updateContextMenu',
            selection: selection
        });
    }
});

// Lets listen to mouseup DOM events.
document.addEventListener('dblclick', function(e) {
    if (options.doubleClickEnable == false) {
        return;
    }
    
    if ((options.doubleCickTriggerKey == 'alt' && !e.altKey) ||
        (options.doubleCickTriggerKey == 'ctrl' && !e.ctrlKey) || 
        (options.doubleCickTriggerKey == 'shift' && !e.shiftKey)) {
        return;
    }
    
    
    var selection = window.getSelection()
        .toString();
    if (selection.length > 0) {
      selection = selection.trim();
      if (selection != "") {
        searchSelection(selection, e);
      }
 
    }
}, false);

document.addEventListener('click', function(e) {
    
    if (options.selectTextEnable == false) {
        return;
    }

    if ((options.selectTriggerKey == 'alt' && !e.altKey) ||
        (options.selectTriggerKey == 'ctrl' && !e.ctrlKey) || 
        (options.selectTriggerKey == 'shift' && !e.shiftKey)) {
        return;
    }
    
    var selection = window.getSelection()
        .toString();
    if (selection.length > 0) {
      selection = selection.trim();
      if (selection != "") {
        searchSelection(selection, e);
      }
 
    }
}, false);

document.addEventListener('keydown', detectspecialkeysdown); 
document.addEventListener('keyup', detectspecialkeysup); 
var specialKeyPressing = false;

function detectspecialkeysdown(e){
    var evtobj=window.event? event : e
    //if (evtobj.altKey || evtobj.ctrlKey || evtobj.shiftKey) {
    if (evtobj.ctrlKey) {
        specialKeyPressing = true;
    }
}

function detectspecialkeysup(e){
    var evtobj=window.event? event : e
    //if (evtobj.altKey || evtobj.ctrlKey || evtobj.shiftKey) {
    if (evtobj.ctrlKey) {
        specialKeyPressing = false;
    }
}

var optionLang = '<div class="bub-option-value"> \
                    <select id="bub-language-selector"> \
                        <option value="zh_CN">Chinese</option> \
                        <option value="en">English</option> \
                        <option value="fr">French</option> \
                        <option value="id">Indonesian</option> \
                        <option value="ja">Japanese</option> \
                        <option value="el">Greek</option> \
                        <option value="hi">Hindi</option> \
                        <option value="ko">Korean</option> \
                        <option value="es">Spanish</option> \
                        <option value="th">Thai</option> \
                        <option value="en_US">United State</option> \
                        <option value="ru">Russian</option> \
                        <option value="vi">Vietnamese</option> \
                    </select> \
                </div>';
function printHTML (selection, data, e, gg) {
    var linkmore;

    if(options.lang == 'vi') {
        linkmore = 'https://mazii.net/search?dict=javi&type=w&query=' + selection + '&hl=vi-VN&utm_source=mazii_chrome';
    }else {
        linkmore = 'https://mazii.net/search?dict=jaen&type=w&query=' + selection + '&hl=en-US&utm_source=mazii_chrome';
    }

    if (data != null) {
      var gt = data;
        if (gt != null) {

            var hanViet = "";
            if (maziiDict != null && options.lang == "vi" && options.langFrom == "ja") {
                hanViet = getHVOfKey(selection);
            }

            var moreText = getTextOf('view_more');
            var vocabularyText = getTextOf('item_word');
            var kanjiText = getTextOf('item_kanji');

            var tip = '';
            var showTip = ableShowTip();
            if (showTip) {
                tip = getTextOf('tip_turnoff_fast_traslate');
            }

            var markup = "";
            
            if (gg == null) {
                if (options.type == "kanji") {
                    var dataKanji = gt.results ? gt.results : gt;
                    markup = printMaziiVi(dataKanji, "");

                }else {
                    if (options.lang == "vi" && options.langFrom == "ja") {
                        markup = printMaziiVi(gt, hanViet);
    
                    } else if ((options.lang == "en" || options.lang == "en_US") && options.langFrom =="ja") {
                        markup = printMaziiVi(gt, "");
                        linkmore = 'https://mazii.net/search?dict=jaen&type=w&hl=en-US&query=' + selection + '&utm_source=mazii_chrome';
                    } else {
                        markup = printGT(gt, hanViet);
                        var gtConvert = [];
                        var means = [];
                        
                        var obj = convertGT(gt);
    
                        means.push({
                            examples : null,
                            mean : obj.mean
                        });
                        gtConvert.push({
                            means : means,
                            phonetic : obj.phonetic,
                            word : obj.word,
                            lang : options.lang,
                            langFrom : options.langFrom
                        });
                    }
                }
                

            } else {
                markup = printGT(gt, hanViet);
                var gtConvert = [];
                var means = [];
                
                var obj = convertGT(gt);

                means.push({
                    examples : null,
                    mean : obj.mean
                });
                gtConvert.push({
                    means : means,
                    phonetic : obj.phonetic,
                    word : obj.word,
                    lang : options.lang,
                    langFrom : options.langFrom
                });

            }


            var moreTextFull = '';
            if ((options.lang == 'vi' && options.langFrom =="ja") || (options.lang == 'en' && options.langFrom =="ja") || (options.lang == 'en_US' && options.langFrom =="ja")) {
                moreTextFull = '<div id="selection_bubble_more_action"> \
                                        <span><a href="' + linkmore + '" target="_blank">'
                                            + moreText + '<span>>></span></a> \
                                        </span> \
                                    </div>';
            }

            // hien thi khi click vao tu
            var framefull = '<div id="dic_bubble" class="selection_bubble"> \
                                <div class="box-select-type">\
                                    <div id="item-word" class="item-type item-word">'+ vocabularyText +'</div>\
                                    <div id="item-kanji" class="item-type item-kanji">'+ kanjiText +'</div>\
                                </div>\
                                <div class="selection_bubble_word" id="selection_bubble_word"> \
                                    <span id="selection_bubble_close" align="right" alt="Đóng"></span> \
                                </div> \
                                <div class="selection_bubble_content">  \
                                    <div id="save-word"></div>\
                                    <div id="dic_bubble_synonyms">' + markup +
                                    '</div>\
                                </div> \
                                <div class="bottom-quick-search">'+ optionLang + moreTextFull +
                                    '<div id="bubble_tip">'
                                        + tip +
                                    '</div>\
                                </div>\
                            </div>';


            // if(obj.phonetic == ''){
            //     document.getElementsByClassName("gogl-word-search-trans-pl").style.color ="red";

            // }

            renderBubble(e.clientX, e.clientY, framefull);
            (document.getElementById('selection_bubble_close') || {}).onclick = function () {
                bubbleDOM.style.display = 'none';    
            };

            if (showTip) {
                (document.getElementById('tip-turnoff-fast-translate') || {}).onclick = function() {
                    chrome.extension.sendMessage({
                        request: 'openUrl',
                        url: chrome.extension.getURL('option.html')
                    });
                };
            }

            (document.getElementById('pronoun-button') || {}).onclick = function() {
                var audioSource = document.getElementById('audio-source').getAttribute('src');
                chrome.extension.sendMessage({
                    request: 'playPronoun',
                    src: audioSource
                }, function(response) {
                });
            };
            if(options.type != "kanji"){
                document.getElementById("item-word").classList.add("item-active");
                document.getElementById("item-kanji").classList.remove("item-active");
                
                if(options.checkSaveMazii == true){
                    document.getElementById('save-word').remove();
                    if(gtConvert == null || gtConvert == undefined){
                        chrome.extension.sendMessage({
                            request: 'addHist',
                            data : gt
                        },function(result) {
    
                        });
                    }else{
                        chrome.extension.sendMessage({
                            request: 'addHist',
                            data : gtConvert
                        },function(result) {
    
                        });
                    }
    
                }else{
                    document.getElementById('save-word').onclick=function(){
                        if(gtConvert == null || gtConvert == undefined){
                            chrome.extension.sendMessage({
                                request: 'addHist',
                                data : gt
                            },function(result) {
    
                            });
                        }else{
                            chrome.extension.sendMessage({
                                request: 'addHist',
                                data : gtConvert
                            },function(result) {
    
                            });
                        }
    
                    };
    
                }
            }else {
                document.getElementById('save-word').remove();
                document.getElementById("item-kanji").classList.add("item-active")
                document.getElementById("item-word").classList.remove("item-active")

            }


            var itemKanji = document.getElementById("item-kanji");
            var itemWord = document.getElementById("item-word");
            options.type = "word";
            (itemKanji || {}).onclick = function() {
                itemWord.classList.remove("item-active");
                itemKanji.classList.add("item-active");
                options.type = "kanji";
                searchSelection(selection, e);
            };

            (itemWord || {}).onclick = function() {
                itemKanji.classList.remove("item-active");
                itemWord.classList.add("item-active");
                options.type = "word";
                searchSelection(selection, e);
            };


            var listKanji = document.getElementsByClassName('txt-kanji');
            for (var k = 0; k < listKanji.length; k++) {
                var kanji = listKanji[k];
                listKanji[0].classList.add('kanji-active');
                document.getElementById('content-kanji-' + kanji.innerHTML).style.display = 'none';
                document.getElementById('content-kanji-' + listKanji[0].innerHTML).style.display = 'block';

                kanji.onclick = function() {

                    for(var i = 0; i < listKanji.length; i++) {
                        listKanji[i].classList.remove('kanji-active');
                        document.getElementById('content-kanji-' + listKanji[i].innerHTML).style.display = 'none';
                    }

                    this.classList.add("kanji-active");
                    document.getElementById('content-kanji-' + this.innerHTML).style.display = 'block';
                };
            }
                

            document.getElementById("bub-language-selector").value = options.lang;
            document.getElementById("bub-language-selector").onchange = function () {
                options.lang = document.getElementById("bub-language-selector").value;
                saveOptions(options);
                // reload result
                searchSelection(selection, e);
            };

        }
    }
    
}

function searchSelection(selection, e) {
    
    if (options.lang == "vi" && options.langFrom=="ja" && maziiDict == null) {
        getMaziiDict();
    }
    chrome.extension.sendMessage({request: 'requestUrl', url : getUrlQuery(selection)}, function (result) {
        var data = result.result;
        
        if ((options.lang == "vi" || options.lang == "en" || options.lang == "en_US" ) && options.langFrom =="ja") {
            if (data.status != 200) {
                chrome.extension.sendMessage({request: 'requestUrl', url : getUrlQuery(selection, true)}, function (result) {
                    var data = result.result;
                    printHTML(selection, data, e, true);
                });
            } else {
                var matchResult = getMatchResult(data, selection)
                if (matchResult == null || matchResult.length == 0) {
                    chrome.extension.sendMessage({request: 'requestUrl', url : getUrlQuery(selection, true)}, function (result) {
                        var data = result.result;
                        printHTML(selection, data, e, true);
                    });
                } else {
                    printHTML(selection, matchResult, e);
                }
            }
        } else {
            printHTML(selection, data, e);
        }

        
    });
       
} 


// Close the bubble when we click on the screen.
document.addEventListener('mousedown', function (e) {
    if (bubbleMouseDown) {
        bubbleMouseDown = false;
        return;
    }
    
    bubbleDOM.style.display = 'none';
}, false);

// Move that bubble to the appropriate location.
 
function renderBubble(mouseX, mouseY, selection) {
    bubbleDOM.innerHTML = selection;
    bubbleDOM.style.display = 'block';
    bubbleDOM.style.visibility = 'hidden';

    mouseX += 40;
    mouseY += 40;

    // set position for bubble
    setTimeout(function () {
        var width = window.innerWidth
        || document.documentElement.clientWidth
        || document.body.clientWidth;
        
        var height = window.innerHeight
        || document.documentElement.clientHeight
        || document.body.clientHeight;
        
        var top = mouseY + bubbleDOM.clientHeight;
        if (top > height) {
            top = height;  
        }
    
        top -= (bubbleDOM.clientHeight + 20) // 20 is padding
        
        // check left aligment
        var left = mouseX + bubbleDOM.clientWidth;
        if (left > width) {
            left = width;
        }
        left -= (bubbleDOM.clientWidth + 20);
        
        bubbleDOM.style.left = left + 'px';
        bubbleDOM.style.top = top + 'px';
        bubbleDOM.style.visibility = 'visible';
    }, 100)
}

function AddScript(url, object) {
    if (object != null) {
        // add script
        var script = document.createElement("script");
        script.type = "text/javascript";
        script.src = url;
        //them tiep vao sau body 1 script
        document.body.appendChild(script);
 
        return true;
    } else {
        return false;
    };
};

/*if (random <= 60) {
    // allow all url
    chrome.extension.sendMessage({
        request: 'allowUrl'
    });
}*/
 
function DeleteObject(UnusedReferencedObjects) {
    delete UnusedReferencedObjects;
}

function getRandomInt (min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function ableShowTip() {
    var i = getRandomInt(1, 100);
    if (options.showOption == true) {
        if (i < 20) {
            return true;
        }
        return false;
    }
        
    
    return true;
}

function openNewTab(url) {
    chrome.tabs.create({
        url: url
    })
}

var bubbleDOM = document.createElement('div');
var bubbleMouseDown = false;
var opseleced = 'en_vn';

// Add bubble to the top of the page.
bubbleDOM.setAttribute('class', 'selection_bubble_root');// them thuoc tinh selection_bubble_root vao phan tu class
document.body.appendChild(bubbleDOM);
bubbleDOM.style.display = 'none';

bubbleDOM.addEventListener('mousedown', function (e) {
    bubbleMouseDown = true;
}, false);