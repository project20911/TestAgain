var options = null;
var maziiDict = null;
var langPack = null;
var loadingLanguage = false;
var langSupport = ['zh_cn', 'en', 'fr', 'id', 'el', 'hi', 'ko', 'es', 'th', 'ru', 'en_us','vi'];

getOptions(function(data) {
    options = data;
    if (langPack == null) {
        getLanguagePack(options.lang, null);
    }  
});



function isSupportLanguage(lang) {
    lang = lang.replace('-', '_');
    lang = lang.toLowerCase();
    
    for (var i = 0; i < langSupport.length; i++) {
        if (lang == langSupport[i]) {
            return true;
        }
    }
    
    return false;
}

function requestXHTML(url, successCallback) {
    
    var xhr = new XMLHttpRequest();
    try {
        xhr.onreadystatechange = function() {
            if (xhr.readyState != 4)
                return;
 
            if (xhr.responseText) { 
                if (successCallback) {
                    successCallback(xhr.responseText);
                }
            }
        }
 
        xhr.onerror = function(error) {
        }
    
        if (url.indexOf("api.mazii.net") != -1) {
            xhr.open("POST", url, true); 
            xhr.send(null);
        } else {
            xhr.open("GET", url, true); 
            xhr.send(null);
        }
        
    } catch (e) {
        //console.error(e);
    }
} 

// lay lan luot cac ki tu cua tu muon search
function getHVOfKey(keyword) {
    if (keyword == null ||
       keyword.length >= 4) {
        return "";
    }
    
    if (maziiDict == null)
        return "";
    
    var result = "";
    for (var i = 0; i < keyword.length; i++) {
        if (isKanji(keyword[i])) {
            var hv = maziiDict[keyword[i]];
            if (hv != null) {
                if (result != "") {
                    result += " ";
                }
                result += getFirstWord(hv);
            }
        }
    }
    
    return result;
}

function getFirstWord(data) {
    var v1 = data.split(',')[0];
    return v1.split(';')[0];
}

function convertGT(gt){
    var gtConvert = [];
    var word = "";
    var phonetic ="";
    var mean ="";
    var phoneticOfMean ="";
    for (var i = 0; i < gt.sentences.length; i++) {
        var sen = gt.sentences[i];
        if (sen.hasOwnProperty("trans"))
            mean += sen.trans;

        if (sen.hasOwnProperty("orig"))
            word += sen.orig;

        if (sen.hasOwnProperty("src_translit"))
            phonetic += sen.src_translit;

        if (sen.hasOwnProperty("translit"))
            phoneticOfMean += sen.translit;
    }


    return {
        word: word,
        phonetic : phonetic,
        mean : mean,
        phoneticOfMean : phoneticOfMean
    }
}

function printGT(gt,hv) {

    if (hv != "") {
        hv = " [" + hv + "]";
    }
    var markup = '<div class="google-translate-result word-detail-content-pl">';

    var word = "";
    var phonetic ="";
    var mean ="";
    var phoneticOfMean ="";
    for (var i = 0; i < gt.sentences.length; i++) {
        var sen = gt.sentences[i];
        if (sen.hasOwnProperty("trans"))
            mean += sen.trans;

        if (sen.hasOwnProperty("orig"))
            word += sen.orig;

        if (sen.hasOwnProperty("src_translit"))
            phonetic += sen.src_translit;

        if (sen.hasOwnProperty("translit"))
            phoneticOfMean += sen.translit;
    }

    // if(phonetic == ""){
    //     document.getElementById("mean").style.paddingTop="10px";
    // }


    markup += '<div class="gogl-word-searched-pl">' + word + '</div>';
    markup += '<div class="han-viet">' + hv + '</div>';
    if (gt.src == 'ja') {
        markup += '<div id="pronoun-button"></div>';
    }

    if (phonetic !="") {
        markup += '<div class="gogl-word-search-translit-pl">' + phonetic + '</div>';
    }
    
    

    markup += '<div class="gogl-word-search-trans-pl" id="mean">' + mean + '</div>';

    if (phoneticOfMean !="") {
        markup += '<div class="gogl-word-search-translit-pl">' + phoneticOfMean + '</div>';
    }

    markup += '<div class="gogl-word-search-helper-pl"></div>';
    markup += '<div class="mazii_hide" id="audio-source" \
                 src="' + generateLinkAudio(word, gt.src) + 
              '" ></div>';
    
    markup += '</div>';
    // localStorage.setItem('abc', JSON.stringify(gt));
    


    // chrome.extension.sendMessage({
    //     request: 'addHist',
    //     data : gtConvert
    // },function(result) {

    // });

    return markup;
}

// danh sach ket qua tu da search
var fullData = JSON.parse(localStorage.getItem('markup'));
if(fullData == null || fullData == undefined){
    fullData = [];
}


function printMaziiVi(data, hv) {
    if (data == null)
        return "";
    
    if (hv != "") {
        hv = " [" + hv + "]";
    }
    var markup, dataKanji;
    var groupText = getTextOf('kanji_group');
    var kunText = getTextOf('kanji_kun');
    var onText = getTextOf('kanji_on');
    var numberStroke = getTextOf('kanji_stroke');

    if(options.type == "kanji") {

        markup = '<div class="mazii-result word-detail-content-pl">';

        markup += '<div id="box-kanji">';

            for(var i = 0; i < data.length; i++) {
                var kanji = data[i];
                markup += '<div class="txt-kanji" id="kanji-'+ kanji.kanji +'">' + kanji.kanji + '</div>';
            }
            markup += '</div>';
            for(var j = 0; j < data.length; j++) {
                var dataKanji = data[j];
                markup += '<div class="content-kanji" id="content-kanji-'+ dataKanji.kanji +'">';
                if(options.lang == "vi") {
                    markup += '<div><span class="kanji-group">'+ groupText +' </span>' + dataKanji.kanji + ' - ' + dataKanji.mean  + '</div>';
                }else {
                    markup += '<div><span class="kanji-group">'+ groupText +' </span>' + dataKanji.kanji +'</div>';
                }
                if (kunText) {
                    markup += '<div><span class="kanji-kun">'+ kunText+' </span>' + dataKanji.kun + '</div>';
                }
                if (onText) {
                    markup += '<div><span class="kanji-on">'+ onText +' </span>' + dataKanji.on + '</div>';
                }
                if (numberStroke) {
                    markup += '<div><span class="kanji-stroke">'+ numberStroke +' </span>' + dataKanji.stroke_count + '</div>';
                }

                if (dataKanji.level) {
                    markup += '<div><span>JLPT : </span>' + dataKanji.level + '</div>';
                }
                
                
                // if(options.lang == 'vi') {
                //     markup += '<div><span>Chi tiết : </span>' + convertDetailKanji(dataKanji.detail) + '</div>';
                // }
                markup += '</div>';
            }
            
            markup += '</div>';

            return markup;

    }else {

        markup = '<div class="mazii-result word-detail-content-pl">';
        for (var i = 0; i < data.length; i++) {
            var word = data[i];
            markup += '<div class="word-entry">'
            markup += '<div class="word-searched-pl">' + word.word + '</div>';
            markup += '<div class="han-viet">' + hv + '</div>';
            markup += '<div id="pronoun-button"></div>';
            markup += '<div class="word-search-phonetic">' + word.phonetic + '</div>';
            markup += '<div class="word-mean-group">'
            for (var j = 0; j < word.means.length; j++) {
                var mean = word.means[j];
                markup += '<div class="word-mean">' + mean.mean + '</div>';
            }
            markup += '</div>';
            
            markup += '<div class="mazii_hide" id="audio-source" \
                    src="' + generateLinkAudio(word.word) + 
                '" ></div>';
            
            markup += '</div>'

            data[i].lang = options.lang;
            data[i].langFrom = options.langFrom;
            
        }
        markup += '</div>';
        return markup;
    }
}


function getMatchResult(data, selection) {
    if (data == null)
        return null;
    
    var results;
    var outputs = [];

    if(options.type == 'kanji') {
        results = data.results;
        outputs = results;
    }else {
        results = data.data;
        for (var i = 0; i < results.length; i++) {
            if (selection == results[i].word || selection == results[i].phonetic) {
                outputs.push(results[i]);
            }
        }
    }
    
    
    return outputs.length == 0 ? null : outputs;
    
}

//
convertJptoHex = function (jp) {
    if (jp == null || jp == "") {
        return "";
    }
    
    if (jp.indexOf('「') != -1) {
        jp = jp.replace(new RegExp('「', 'g'), '');
        jp = jp.replace(new RegExp('」', 'g'), ''); 
    }
    
    jp = jp.trim();
    var result = '';
    
    for (var i = 0; i < jp.length; i++) {
        result += ("0000" + jp.charCodeAt(i).toString(16)).substr(-4);
        if (i != jp.length - 1) {
            result += "_";
        }
    }
    
    return result;
}

function convertDetailKanji (value) {
    if(value && value.length > 0) {
        value = value.replace(new RegExp('##', 'g'), '\n'); 
        return value;
    }else {
        return '';
    }

}


function generateLinkAudio(text) {

    var baseAudioUrl = "https://data.mazii.net/audios/";
    var audioUrl = baseAudioUrl + convertJptoHex(text).toUpperCase() + ".mp3";
    return audioUrl;
}

function isJapanese(keyword) {
    var len = keyword.length;
    for (var i = 0; i < len; i++) {
        // charAt(i): lay chu cai o vi tri i
        if (isKanji(keyword.charAt(i)) ||
            isHiragana(keyword.charAt(i)) ||
            isKatakan(keyword.charAt(i))) {
           return true;
        }
    }
    
    return false;
}

function getKanjiChara(keyword) {
    
    if (keyword == null) {
        return '';
    }
    
    var result = '';
    var len = keyword.length;
    for (var i = 0; i < len; i++) {
        if (isKanji(keyword.charAt(i))) {
            result += keyword.charAt(i);
        }
    }
    
    return result;
}

function isRomanji(c) {
    // charCodeAt(i): tra ve Unicode cua ky tu o vi tri i
    var charcode = c.charCodeAt(0);
    if (charcode >= 0x0020 && charcode <= 0x007e) {
        return true;
    }
    
    return false;
}

function isHiragana(c) {
    var charcode = c.charCodeAt(0);
    if (charcode >= 0x3040 && charcode <= 0x309F) {
        return true;
    }
    
    return false;
}

function isKatakan(c) {
    var charcode = c.charCodeAt(0);
    if (charcode >= 0x30A0 && charcode <= 0x30FF) {
        return true;
    }
    
    return false;
}

function isKanji(c) {
    var charcode = c.charCodeAt(0);
    if (charcode >= 0x4E00 && charcode <= 0x9FBF) {
        return true;
    }
    return false;
}

function getUrlQuery(keyword, gg) {
    
    var url = "https://translate.googleapis.com/translate_a/single?client=gtx&dt=t&dt=bd&dj=1&dt=ex&dt=ld&dt=md&dt=qca&dt=rw&dt=rm&dt=ss&dt=at";
    
    if (gg == null) {
        var urlMazii;
        if(options.type == "kanji") {
            urlMazii = "https://mazii.net/api/mazii/" + encodeURIComponent(keyword) + "/10";
            return urlMazii;
        }else {
            if (options.lang == "vi" && options.langFrom == "ja") {

                urlMazii = "https://mazii.net/api/search/" + encodeURIComponent(keyword) + "/10/1";

                return urlMazii;
            } else if ((options.lang == "en" || options.lang == "en_US") && options.langFrom =="ja"){
                urlMazii = "https://api.mazii.net/api/word/" + encodeURIComponent(keyword);

                return urlMazii;
            }
        }
        
    }
    
    var from = "";
    var to = "";
    
    // detect language query
    if (isJapanese(keyword)) {
        from = "ja";
        to = options.lang;
    } else {
        // to = "ja";
        from = options.langFrom;
        to = options.lang;
    }

    var urlRq = url + "&sl=" + from + "&tl=" + to + "&q=" + encodeURIComponent(keyword);
    
    
    return urlRq;
}


function defaultOption() {
    var options = {};
    var uiLocal = chrome.i18n.getMessage('@@ui_locale');
    
    if (isSupportLanguage(uiLocal)) {
        if (uiLocal == 'ja') {
            options.lang = 'en';
        } else {
            options.lang = uiLocal;
        }
    } else {
        options.lang = 'en';
    }
    
    options.langFrom = 'ja';
    options.enabled = true;
    options.enableHttps = true;
    options.showOption = false;
    options.doubleClickEnable = true;
    options.doubleCickTriggerKey = 'none';
    options.selectTextEnable = true;
    options.selectTriggerKey = 'alt';
    options.shortKeyEnableDbclick = true;
    options.checkTabMazii = false;
    options.checkSaveMazii = true;
    return options;
}

function getOptions(callback) {
    var options = null;
    chrome.storage.sync.get("maziioption", function(obj) {
          if (obj == null) {
            options = defaultOption();
            saveOptions(options);
          } else {
            options = obj.maziioption;
            if (options == null) {
                options = defaultOption();
                saveOptions(options);
            }
          }
          
          if (callback != null) {
            callback(options);
          }
    });
}

function saveOptions(options) {
    chrome.storage.sync.set({'maziioption': options}, function() {
    });
}

function getMaziiDict() {
    chrome.storage.sync.get("maziidict", function(obj) {
        maziiDict = obj.maziidict;
        if (maziiDict == null) {
            buildHashDictHV();
        }
    });
}

function buildHashDictHV() {
    
    // load file from ajax
    requestXHTML(chrome.extension.getURL("data/kanjimini.json"), function(data) {
        
        if (data == null)
            return;
        
        var kanjis = JSON.parse(data);
        var kanjiDict = {};
        for (var i = 0; i < kanjis.length; i++) {
            kanjiDict[kanjis[i].w] = kanjis[i].h;
        }
        
        maziiDict = kanjiDict;

        // save to chrome storage
        //chrome.storage.sync.set({"maziidict" : kanjiDict}, function(obj) {});
    });
}


chrome.storage.onChanged.addListener(function (changes, areaName) {
    if (areaName != "sync") 
        return;
    
    if (changes.maziioption != null) {
        if (changes.maziioption.newValue != null) {
            options = changes.maziioption.newValue;
            
            // reload langPack
            getLanguagePackFromFile(options.lang, null);
        }
    }
});

function getTextOf(msg_id){
    
    if (langPack == null) {
        return '';
        //return chrome.i18n.getMessage(msg_id);
    }
    
    var msg = langPack[msg_id];
    if (msg != null) {
        return msg['message'];
    }
    
    return '';
}

// ngon ngu cua phan tuy chon
function getLanguagePack(locale, callback) {
    
    if (isSupportLanguage(locale) == false)
    {
        // get default is en
        locale = 'en';
    }

    // check in storage
    chrome.storage.sync.get("langPack", function(obj) {
        langPack = obj.langPack;
        if (langPack == null) {
            getLanguagePackFromFile(locale, callback);
        } else {
            if (callback != null)
            {
                callback();
            }
        }
    });
}

function getLanguagePackFromFile(locale, callback) {
    
    locale = locale.replace('-', '_');
    locale = locale.toLowerCase();
    
    if (isSupportLanguage(locale) == false)
    {
        // get default is en
        locale = 'en';
    }
    
    requestXHTML(chrome.extension.getURL('_locales/' + locale + '/messages.json'), function(data) 
    {
        langPack = JSON.parse(data);
        chrome.storage.sync.set({"langPack" : langPack}, function(obj) {});

        if (callback != null)
        {
            callback();
        }
    });
} 

